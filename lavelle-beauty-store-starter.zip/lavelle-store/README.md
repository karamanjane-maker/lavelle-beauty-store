# Lavelle Beauty Store — starter project

This is a responsive customer storefront plus a private admin dashboard starter for **Lavelle**.

## Included
- Pink/feminine storefront design
- Product catalogue loaded from Supabase
- Simple order form with customer contact, delivery address and payment selection
- Order records stored in Supabase
- Private admin sign-in, order list and status updates
- Add products, edit names/prices/descriptions/image URLs, and publish/hide products from phone or laptop
- WhatsApp handoff: after an order is saved, the customer gets a pre-filled WhatsApp message to send to Lavelle. Admin can also message customers from an order.

## Important WhatsApp limitation
This starter does **not** silently send automatic WhatsApp messages to the store owner. WhatsApp requires a Meta WhatsApp Business Platform account, phone-number registration, an access token, and usually an approved message template for business-initiated notifications. The current safe first version opens WhatsApp with a prepared order message for the customer to send. Automatic owner alerts can be added after the Meta setup is complete.

## Setup

### 1. Create Supabase project
1. Create a project at https://supabase.com/
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Project Settings → API, copy the Project URL and anon/public key.
4. In Authentication → Users, create your admin user with your own email and a strong password.
5. In the Supabase SQL editor, assign the admin role to that user (replace the email):

```sql
update auth.users
set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
where email = 'YOUR_ADMIN_EMAIL';
```

Sign out and back in after changing the role.

### 2. Configure the app
1. Install Node.js (LTS).
2. Copy `.env.example` to `.env.local`.
3. Add your Supabase URL and anon key.
4. Run:

```bash
npm install
npm run dev
```

5. Open http://localhost:3000 for the customer website.
6. Open http://localhost:3000/admin for your private dashboard.

### 3. Add product photos
The first version accepts publicly accessible image URLs in the admin product form. For a production launch, configure Supabase Storage and add direct image uploads with file validation.

### 4. Publish online
Deploy the project to https://vercel.com/ and add the same environment variables in the project settings. Connect a domain if you own one, then put the public storefront URL in your Instagram bio. Keep `/admin` private and use a strong password.

## Before accepting real orders
- Add anti-spam/rate limiting and server-side order validation.
- Add image uploads via Supabase Storage.
- Confirm delivery fees, final pricing, stock handling and refund/cancellation policies.
- Test an order on a phone and laptop.
- Do not put any Supabase service-role key in browser code or a `NEXT_PUBLIC_` variable.
- Restrict admin access to your own account and enable strong authentication.

## Business details prefilled
- Brand: Lavelle
- WhatsApp: +961 81 481 344
- Currency display: USD
- Payment choices: Cash on delivery, Whish Money, OMT, Bank transfer
