-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price numeric(10,2) not null check (price >= 0),
  image_url text,
  category text default 'Skincare',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  address text not null,
  payment_method text not null,
  notes text,
  items jsonb not null,
  total numeric(10,2) not null check (total >= 0),
  status text not null default 'pending'
    check (status in ('pending','confirmed','shipped','delivered','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
alter table public.orders enable row level security;

-- Visitors can see active products only.
create policy "Public can view active products"
on public.products for select
using (active = true or (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Only an authenticated admin can add/change/hide products.
create policy "Admin can manage products"
on public.products for all
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Customers can submit orders. Do not expose order reads publicly.
create policy "Visitors can submit orders"
on public.orders for insert
with check (
  length(customer_name) between 2 and 100
  and length(phone) between 6 and 30
  and length(address) between 5 and 500
);

-- Only admin can view/update orders.
create policy "Admin can view orders"
on public.orders for select
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

create policy "Admin can update orders"
on public.orders for update
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

grant select on public.products to anon, authenticated;
grant insert on public.orders to anon, authenticated;
grant select, insert, update, delete on public.products to authenticated;
grant select, update on public.orders to authenticated;
