 "use client";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "../lib/supabase";

type Product = { id:string; name:string; description:string|null; price:number; image_url:string|null; category:string|null; active:boolean };
export default function Home(){
  const [products,setProducts]=useState<Product[]>([]);
  const [qty,setQty]=useState<Record<string,number>>({});
  const [form,setForm]=useState({name:"",phone:"",address:"",payment:"Cash on delivery",notes:""});
  const [busy,setBusy]=useState(false); const [message,setMessage]=useState("");
  useEffect(()=>{supabase.from("products").select("*").eq("active",true).order("created_at",{ascending:false}).then(({data})=>setProducts(data||[]));},[]);
  const chosen=useMemo(()=>products.filter(p=>(qty[p.id]||0)>0).map(p=>({...p,quantity:qty[p.id]})),[products,qty]);
  const total=chosen.reduce((s,p)=>s+Number(p.price)*p.quantity,0);
  async function submit(e:React.FormEvent){
    e.preventDefault(); if(!chosen.length){setMessage("Please choose at least one product.");return;}
    setBusy(true);setMessage("");
    const payload={customer_name:form.name,phone:form.phone,address:form.address,payment_method:form.payment,notes:form.notes,items:chosen.map(p=>({product_id:p.id,name:p.name,price:p.price,quantity:p.quantity})),total};
    const orderId=crypto.randomUUID();
    const {error}=await supabase.from("orders").insert({...payload,id:orderId});
    setBusy(false);
    if(error){setMessage("We couldn't submit your order. Please try again or contact us on WhatsApp.");return;}
    const lines=chosen.map(p=>`${p.name} x ${p.quantity} — $${(p.price*p.quantity).toFixed(2)}`).join("\n");
    const msg=`Hello Lavelle! I'd like to place order #${orderId.slice(0,8)}.\n\n${lines}\nTotal: $${total.toFixed(2)}\n\nName: ${form.name}\nPhone: ${form.phone}\nAddress: ${form.address}\nPayment: ${form.payment}\nNotes: ${form.notes||"None"}`;
    setMessage("Your order has been saved. Please send the prepared WhatsApp message to complete your order notification.");
    window.open(`https://wa.me/96181481344?text=${encodeURIComponent(msg)}`,"_blank");
    setQty({});setForm({name:"",phone:"",address:"",payment:"Cash on delivery",notes:""});
  }
  return <main className="wrap">
    <header className="topbar"><a className="logo" href="#">LAVELLE</a><a className="pill" href="#order">Place an order</a></header>
    <section className="hero"><div><div className="eyebrow">Beauty • Skincare • Self-care</div><h1>Your beauty,<br/>your ritual.</h1><p className="lead">Thoughtfully chosen beauty essentials to make every day feel a little more beautiful. Discover your favorites at Lavelle.</p><a className="btn" href="#products">Explore products ↓</a></div><div className="hero-art">LAVELLE</div></section>
    <section className="section" id="products"><div className="section-head"><div><div className="eyebrow">The collection</div><h2>Find your favorites</h2><p className="muted">Add the products you love to your order below.</p></div></div>
      {products.length===0?<div className="panel"><h3>Our collection is coming soon</h3><p className="muted">Lavelle's products will appear here once the store owner adds them in the admin dashboard.</p></div>:<div className="grid">{products.map(p=><article className="product" key={p.id}><div className="product-img">{p.image_url?<img src={p.image_url} alt={p.name}/>:<span>Lavelle Beauty</span>}</div><h3>{p.name}</h3><p className="muted">{p.description}</p><div className="price">${Number(p.price).toFixed(2)}</div><div className="order-row"><span className="muted">Quantity</span><input aria-label={`Quantity for ${p.name}`} type="number" min="0" value={qty[p.id]||0} onChange={e=>setQty({...qty,[p.id]:Math.max(0,Number(e.target.value))})}/></div></article>)}</div>}
    </section>
    <section className="section" id="order"><div className="eyebrow">Almost yours</div><h2>Place your order</h2><div className="panel">
      <form onSubmit={submit}><div className="formgrid">
        <div className="field full"><label>Your selected products</label>{chosen.length?chosen.map(p=><div className="order-row" key={p.id}><span>{p.name} × {p.quantity}</span><strong>${(p.price*p.quantity).toFixed(2)}</strong></div>):<p className="muted">Choose products above to see them here.</p>}<strong>Order subtotal: ${total.toFixed(2)}</strong></div>
        <div className="field"><label>Full name *</label><input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></div>
        <div className="field"><label>WhatsApp / phone *</label><input required value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></div>
        <div className="field full"><label>Delivery address *</label><textarea required rows={2} value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/></div>
        <div className="field"><label>Payment method</label><select value={form.payment} onChange={e=>setForm({...form,payment:e.target.value})}><option>Cash on delivery</option><option>Whish Money</option><option>OMT</option><option>Bank transfer</option></select></div>
        <div className="field"><label>Order notes</label><input value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} placeholder="Optional"/></div>
        <div className="field full"><button className="btn" disabled={busy}>{busy?"Submitting…":"Submit order & notify Lavelle on WhatsApp"}</button>{message&&<p className="muted" role="status">{message}</p>}<p className="muted">Submitting saves your order. WhatsApp opens with the order details; tap Send in WhatsApp to message Lavelle. Delivery fees and final total are confirmed with you.</p></div>
      </div></form>
    </div></section>
    <footer className="footer">LAVELLE · Beauty made personal · WhatsApp: +961 81 481 344</footer>
  </main>;
}