import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Lavelle | Beauty & Skincare",
  description: "Discover your everyday beauty essentials at Lavelle.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}